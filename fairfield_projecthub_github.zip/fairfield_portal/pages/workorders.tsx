export default function WorkOrders() {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Work Orders</h2>
      <p>Work order management and progress tracking will go here.</p>
    </div>
  );
}