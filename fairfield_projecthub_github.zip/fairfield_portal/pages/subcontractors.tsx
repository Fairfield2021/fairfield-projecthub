export default function Subcontractors() {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Subcontractors</h2>
      <p>Subcontractor roles and assignment tracking will go here.</p>
    </div>
  );
}